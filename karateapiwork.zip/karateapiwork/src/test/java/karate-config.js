function fn() {
  var env = 'int';
  karate.log('karate.env system property was:', env);

  if (!env) {
    env = 'int'; // a custom 'intelligent' default
  }
  var config = { // base config JSON
    appId: 'my.app.id',
    appSecret: 'my.secret',
    SOME_URL_BASE: 'https://some-host.com/v1/auth/',
    ANOTHER_URL_BASE: 'https://another-host.com/v1/'
  };

  if (env == 'int') {
    // over-ride only those that need to be
    config.SOME_URL_BASE = 'https://stage-host/v1/auth';
  } else if (env == 'pqa') {
    config.SOME_URL_BASE = 'https://e2e-host/v1/auth';
  }

  return config;
}